
import React, { useEffect, useRef } from 'react';
import Quill from 'quill';
import 'quill/dist/quill.snow.css';
import { io } from 'socket.io-client';

function App() {
  const editorRef = useRef();
  const socketRef = useRef();

  useEffect(() => {
    const editor = new Quill(editorRef.current, {
      theme: 'snow',
    });

    socketRef.current = io('http://localhost:3001');

    editor.on('text-change', (delta) => {
      socketRef.current.emit('send-changes', delta);
    });

    socketRef.current.on('receive-changes', (delta) => {
      editor.updateContents(delta);
    });
  }, []);

  return <div className="container" ref={editorRef}></div>;
}

export default App;
