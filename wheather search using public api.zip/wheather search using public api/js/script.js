/*let currentWeatherCondition = "";
let currentCity = "";

async function getWeather() {
  const city = document.getElementById("cityInput").value.trim();
  const apiKey = "9b8a2322ee21f0f7d241249fa8ac6eaa";

  if (!city) {
    alert("Please enter a city name");
    return;
  }

  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("City not found");

    const data = await response.json();
    const temp = data.main.temp;

    // Update UI
    const weatherResult = `
      <h2>${data.name}, ${data.sys.country}</h2>
      <p>Temp: ${temp}°C</p>
      <p>Humidity: ${data.main.humidity}%</p>
      <p>Wind Speed: ${data.wind.speed} m/s</p>
      <p>Weather: ${data.weather[0].main}</p>
    `;
    document.getElementById("weatherResult").innerHTML = weatherResult;

    // Send search to backend
    fetch("save_search.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `city=${encodeURIComponent(city)}`
    });

  } catch (error) {
    document.getElementById("weatherResult").innerHTML = `<p "color:white">${error.message}</p>`;
  }
}

// Add Enter key support
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("cityInput").addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      getWeather();
    }
  });
});*/




// Sample Tourist Data
const touristData = {
    "delhi": [
        { name: "India Gate", desc: "War memorial in New Delhi." },
        { name: "Red Fort", desc: "Historic Mughal fortress." },
        { name: "Qutub Minar", desc: "Tallest brick minaret in the world." }
    ],
    "paris": [
        { name: "Eiffel Tower", desc: "Iconic symbol of France." },
        { name: "Louvre Museum", desc: "World's largest art museum." },
        { name: "Notre-Dame", desc: "Famous Gothic cathedral." }
    ],
    "new york": [
        { name: "Statue of Liberty", desc: "Iconic national monument." },
        { name: "Central Park", desc: "Famous urban park." },
        { name: "Times Square", desc: "Bustling entertainment hub." }
    ],
    "london": [
        { name: "Big Ben", desc: "Famous clock tower." },
        { name: "London Eye", desc: "Giant observation wheel." },
        { name: "Tower Bridge", desc: "Iconic drawbridge." }
    ],
    "paris": [
        { name: "Eiffel Tower", desc: "Iconic iron tower." },
        { name: "Louvre Museum", desc: "Famous art museum." },
        { name: "Notre-Dame Cathedral", desc: "Historic gothic cathedral." }
    ],
    "tokyo": [
        { name: "Tokyo Tower", desc: "Communications and observation tower." },
        { name: "Shibuya Crossing", desc: "Famous busy intersection." },
        { name: "Senso-ji Temple", desc: "Ancient Buddhist temple." }
    ],
    "sydney": [
        { name: "Sydney Opera House", desc: "Famous performing arts venue." },
        { name: "Harbour Bridge", desc: "Steel arch bridge." },
        { name: "Bondi Beach", desc: "Popular surf beach." }
    ],
    "dubai": [
        { name: "Burj Khalifa", desc: "Tallest building in the world." },
        { name: "Dubai Mall", desc: "Large shopping center." },
        { name: "Palm Jumeirah", desc: "Artificial island." }
    ],
    "rome": [
        { name: "Colosseum", desc: "Ancient Roman amphitheater." },
        { name: "Trevi Fountain", desc: "Famous Baroque fountain." },
        { name: "Pantheon", desc: "Ancient Roman temple." }
    ],
    "singapore": [
        { name: "Marina Bay Sands", desc: "Iconic luxury resort." },
        { name: "Gardens by the Bay", desc: "Nature park with Supertrees." },
        { name: "Sentosa Island", desc: "Popular island resort." }
    ],
    "istanbul": [
        { name: "Hagia Sophia", desc: "Historic church and mosque." },
        { name: "Blue Mosque", desc: "Iconic Ottoman-era mosque." },
        { name: "Grand Bazaar", desc: "Large covered market." }
    ],
    "bangkok": [
        { name: "Grand Palace", desc: "Royal residence complex." },
        { name: "Wat Arun", desc: "Temple of Dawn." },
        { name: "Chatuchak Market", desc: "Massive weekend market." }
    ],
   "barcelona": [
        { name: "Sagrada Família", desc: "Iconic basilica designed by Gaudí." },
        { name: "Park Güell", desc: "Colorful park with mosaic art." },
        { name: "La Rambla", desc: "Famous street with shops and cafes." }
    ],
    "moscow": [
        { name: "Red Square", desc: "Historic central square." },
        { name: "St. Basil's Cathedral", desc: "Colorful domed church." },
        { name: "Kremlin", desc: "Fortress and official residence." }
    ],
    "los angeles": [
        { name: "Hollywood Sign", desc: "Iconic symbol of the entertainment industry." },
        { name: "Santa Monica Pier", desc: "Famous pier with amusement park." },
        { name: "Griffith Observatory", desc: "Scenic spot with space exhibits." }
    ],
    "toronto": [
        { name: "CN Tower", desc: "Famous observation tower." },
        { name: "Royal Ontario Museum", desc: "Major museum with diverse exhibits." },
        { name: "Ripley's Aquarium", desc: "Large indoor aquarium." }
    ],
    "mumbai": [
        { name: "Gateway of India", desc: "Colonial-era arch monument." },
        { name: "Marine Drive", desc: "Picturesque coastal road." },
        { name: "Elephanta Caves", desc: "Ancient rock-cut temples." }
    ],
    "berlin": [
        { name: "Brandenburg Gate", desc: "18th-century neoclassical monument." },
        { name: "Berlin Wall", desc: "Historic remnants of the Cold War." },
        { name: "Museum Island", desc: "Complex of major museums." }
    ],
    "beijing": [
        { name: "Great Wall of China", desc: "World-renowned ancient wall." },
        { name: "Forbidden City", desc: "Historic imperial palace." },
        { name: "Temple of Heaven", desc: "Famous Taoist temple complex." }
    ],
    "bali": [
        { name: "Uluwatu Temple", desc: "Clifftop Hindu sea temple." },
        { name: "Tegallalang Rice Terraces", desc: "Famous scenic rice fields." },
        { name: "Ubud Monkey Forest", desc: "Nature reserve and temple complex." }
    ],
    "san francisco": [
        { name: "Golden Gate Bridge", desc: "Famous red suspension bridge." },
        { name: "Alcatraz Island", desc: "Infamous former prison." },
        { name: "Fisherman's Wharf", desc: "Popular waterfront district." }
    ],
    "amsterdam": [
        { name: "Rijksmuseum", desc: "Famous Dutch national museum." },
        { name: "Anne Frank House", desc: "Historic home of Anne Frank." },
        { name: "Canal Ring", desc: "Scenic network of canals." }
    ],
     "rome": [
        { name: "Colosseum", desc: "Ancient Roman gladiator arena." },
        { name: "Trevi Fountain", desc: "Famous Baroque fountain." },
        { name: "Pantheon", desc: "Well-preserved ancient Roman temple." }
    ],
    "istanbul": [
        { name: "Hagia Sophia", desc: "Historic mosque and museum." },
        { name: "Blue Mosque", desc: "Iconic Ottoman-era mosque." },
        { name: "Topkapi Palace", desc: "Ottoman imperial residence." }
    ],
    "singapore": [
        { name: "Marina Bay Sands", desc: "Iconic hotel and infinity pool." },
        { name: "Gardens by the Bay", desc: "Futuristic park with Supertrees." },
        { name: "Sentosa Island", desc: "Popular island resort getaway." }
    ],
    "dubai": [
        { name: "Burj Khalifa", desc: "World's tallest building." },
        { name: "Palm Jumeirah", desc: "Man-made island shaped like a palm." },
        { name: "Dubai Mall", desc: "Massive shopping and entertainment center." }
    ],
    "prague": [
        { name: "Charles Bridge", desc: "Historic stone bridge with statues." },
        { name: "Prague Castle", desc: "Largest ancient castle in the world." },
        { name: "Old Town Square", desc: "Historic center with Astronomical Clock." }
    ],
    "seoul": [
        { name: "Gyeongbokgung Palace", desc: "Historic royal palace." },
        { name: "N Seoul Tower", desc: "Observation tower with panoramic views." },
        { name: "Bukchon Hanok Village", desc: "Traditional Korean village." }
    ],
    "athens": [
        { name: "Acropolis", desc: "Ancient citadel with Parthenon." },
        { name: "Temple of Olympian Zeus", desc: "Massive ruined temple." },
        { name: "Plaka District", desc: "Historic neighborhood under Acropolis." }
    ],
    "mexico city": [
        { name: "Zócalo", desc: "Main square with historic buildings." },
        { name: "Chapultepec Castle", desc: "Historic castle in a city park." },
        { name: "Frida Kahlo Museum", desc: "House and museum of the famous artist." }
    ],
    "rio de janeiro": [
        { name: "Christ the Redeemer", desc: "Iconic statue atop Corcovado." },
        { name: "Sugarloaf Mountain", desc: "Scenic views via cable car." },
        { name: "Copacabana Beach", desc: "Famous sandy beach." }
    ],
    "venice": [
        { name: "Grand Canal", desc: "Main waterway through the city." },
        { name: "St. Mark’s Basilica", desc: "Ornate cathedral in Piazza San Marco." },
        { name: "Rialto Bridge", desc: "Famous stone bridge over the canal." }
    ],
    "madrid": [
        { name: "Royal Palace of Madrid", desc: "Official residence of the Spanish royal family." },
        { name: "Prado Museum", desc: "Famous museum with European art." },
        { name: "Retiro Park", desc: "Historic park with gardens and lake." }
    ],
    "lisbon": [
        { name: "Belém Tower", desc: "Iconic fortress and UNESCO site." },
        { name: "Jerónimos Monastery", desc: "Stunning Gothic monastery." },
        { name: "Alfama District", desc: "Historic area with Fado music." }
    ],
    "jakarta": [
        { name: "National Monument (Monas)", desc: "Tower symbolizing Indonesian independence." },
        { name: "Taman Mini Indonesia Indah", desc: "Cultural park showcasing Indonesian diversity." },
        { name: "Old Town (Kota Tua)", desc: "Historic colonial district." }
    ],
    "cairo": [
        { name: "Pyramids of Giza", desc: "Ancient wonders of the world." },
        { name: "Egyptian Museum", desc: "Houses extensive collection of antiquities." },
        { name: "Khan el-Khalili", desc: "Bustling traditional bazaar." }
    ],
    "amsterdam": [
        { name: "Rijksmuseum", desc: "Dutch national museum with art and history." },
        { name: "Anne Frank House", desc: "Historic site of WWII diary." },
        { name: "Van Gogh Museum", desc: "Collection of Van Gogh’s artwork." }
    ],
    "moscow": [
        { name: "Red Square", desc: "Central square of Moscow." },
        { name: "St. Basil’s Cathedral", desc: "Famous colorful onion domes." },
        { name: "Kremlin", desc: "Fortified complex and official residence." }
    ],
    "vienna": [
        { name: "Schönbrunn Palace", desc: "Former imperial summer residence." },
        { name: "St. Stephen’s Cathedral", desc: "Gothic landmark in the city center." },
        { name: "Belvedere Palace", desc: "Baroque palaces and gardens." }
    ],
    "beijing": [
        { name: "Great Wall of China", desc: "Iconic ancient fortification." },
        { name: "Forbidden City", desc: "Historic imperial palace complex." },
        { name: "Temple of Heaven", desc: "Medieval complex used for ceremonies." }
    ],
    "oslo": [
        { name: "Vigeland Park", desc: "Largest sculpture park by a single artist." },
        { name: "Akershus Fortress", desc: "Medieval castle with sea views." },
        { name: "Fram Museum", desc: "Exploration museum featuring Arctic ship." }
    ],
    "stockholm": [
        { name: "Vasa Museum", desc: "Museum housing a preserved warship." },
        { name: "Gamla Stan", desc: "Old town with colorful buildings." },
        { name: "Skansen", desc: "Open-air museum and zoo." }
    ],
    "zurich": [
        { name: "Old Town (Altstadt)", desc: "Charming historic area with cobbled streets." },
        { name: "Lake Zurich", desc: "Scenic lake popular for boat tours." },
        { name: "Uetliberg Mountain", desc: "Offers panoramic views of the city." }
    ],
    "helsinki": [
        { name: "Suomenlinna", desc: "Sea fortress and UNESCO World Heritage site." },
        { name: "Helsinki Cathedral", desc: "Iconic white Lutheran cathedral." },
        { name: "Market Square", desc: "Bustling waterfront market." }
    ],
    "copenhagen": [
        { name: "Nyhavn", desc: "Colorful harborfront with restaurants." },
        { name: "Tivoli Gardens", desc: "Historic amusement park." },
        { name: "The Little Mermaid", desc: "Famous bronze statue by the water." }
    ],
    "prague": [
        { name: "Charles Bridge", desc: "Historic bridge with statues and views." },
        { name: "Prague Castle", desc: "Largest ancient castle in the world." },
        { name: "Old Town Square", desc: "Historic square with astronomical clock." }
    ],
    "warsaw": [
        { name: "Old Town", desc: "Rebuilt historic center and UNESCO site." },
        { name: "Royal Castle", desc: "Former residence of Polish monarchs." },
        { name: "Lazienki Park", desc: "Palaces, gardens, and lakes." }
    ],
    "budapest": [
        { name: "Buda Castle", desc: "Historical castle and museum complex." },
        { name: "Parliament Building", desc: "Neo-Gothic riverside landmark." },
        { name: "Széchenyi Thermal Bath", desc: "Famous spa with hot spring pools." }
    ],
    "brussels": [
        { name: "Grand Place", desc: "Central square surrounded by ornate buildings." },
        { name: "Atomium", desc: "Unique architectural landmark and museum." },
        { name: "Manneken Pis", desc: "Famous bronze statue of a little boy." }
    ],
    "bucharest": [
        { name: "Palace of the Parliament", desc: "Second largest administrative building in the world." },
        { name: "Old Town (Lipscani)", desc: "Historic district with cafes and nightlife." },
        { name: "Village Museum", desc: "Open-air museum of traditional Romanian houses." }
    ],
    "athens": [
        { name: "Acropolis of Athens", desc: "Ancient citadel with the Parthenon." },
        { name: "Temple of Olympian Zeus", desc: "Ruins of a grand ancient temple." },
        { name: "Plaka", desc: "Old neighborhood with shops and cafes." }
    ],
    "sofia": [
        { name: "Alexander Nevsky Cathedral", desc: "Iconic Orthodox cathedral with golden domes." },
        { name: "Vitosha Mountain", desc: "Popular for hiking and skiing near the city." },
        { name: "Boyana Church", desc: "UNESCO site with medieval frescoes." }
    ],
    "oslo": [
        { name: "Vigeland Park", desc: "Sculpture park with over 200 bronze and granite figures." },
        { name: "Oslo Opera House", desc: "Modern architecture with roof access for views." },
        { name: "Fram Museum", desc: "Exhibits on polar exploration." }
    ],
    "stockholm": [
        { name: "Gamla Stan", desc: "Stockholm’s Old Town with colorful buildings." },
        { name: "Vasa Museum", desc: "Warship museum with a preserved 17th-century vessel." },
        { name: "Skansen", desc: "Open-air museum and zoo." }
    ],
    "reykjavik": [
        { name: "Hallgrímskirkja", desc: "Iconic modernist church with panoramic tower." },
        { name: "Blue Lagoon", desc: "Geothermal spa in lava field." },
        { name: "Perlan", desc: "Glass dome museum with views and exhibitions." }
    ],
    "edinburgh": [
        { name: "Edinburgh Castle", desc: "Historic fortress overlooking the city." },
        { name: "Royal Mile", desc: "Historic street connecting the castle and Holyrood Palace." },
        { name: "Arthur’s Seat", desc: "Extinct volcano and popular hiking spot." }
    ],
    "glasgow": [
        { name: "Kelvingrove Art Gallery", desc: "Impressive art museum with diverse collections." },
        { name: "Glasgow Cathedral", desc: "Medieval church and gothic architecture." },
        { name: "The Riverside Museum", desc: "Transport museum with interactive exhibits." }
    ],
    "dublin": [
        { name: "Trinity College & Book of Kells", desc: "Historic university and illuminated manuscript." },
        { name: "Guinness Storehouse", desc: "Brewery tour and rooftop bar." },
        { name: "Dublin Castle", desc: "Historic government complex." }
    ],
    "lisbon": [
        { name: "Belem Tower", desc: "Historic fortress by the river." },
        { name: "Jerónimos Monastery", desc: "Ornate monastery and UNESCO site." },
        { name: "Alfama District", desc: "Old quarter with narrow lanes and Fado music." }
    ],
    "porto": [
        { name: "Dom Luís I Bridge", desc: "Double-deck iron bridge over the Douro River." },
        { name: "Livraria Lello", desc: "Famous bookshop with ornate staircase." },
        { name: "Ribeira District", desc: "Historic riverside quarter." }
    ],
    "valletta": [
        { name: "St. John's Co-Cathedral", desc: "Lavish baroque interior and Caravaggio art." },
        { name: "Upper Barrakka Gardens", desc: "Scenic gardens with harbor views." },
        { name: "Grandmaster's Palace", desc: "Historic palace with armory and state rooms." }
    ],
    "monaco": [
        { name: "Monte Carlo Casino", desc: "World-famous casino and architectural gem." },
        { name: "Prince’s Palace", desc: "Official residence of the Prince of Monaco." },
        { name: "Oceanographic Museum", desc: "Marine science museum on a cliff." }
    ],
    "dull": [
        { name: "Welcome Sign", desc: "Snap a selfie with the ‘Dull’ town sign — it’s a real place in Scotland!" },
        { name: "Dull and Boring Road", desc: "Road twinned with Boring, Oregon — ironically exciting!" },
        { name: "Highland Scenery", desc: "Despite the name, the landscape is stunning." }
    ],
    "boring": [
        { name: "City Welcome Sign", desc: "People visit just to say they’ve been to 'Boring' in Oregon!" },
        { name: "Boring Station Trailhead", desc: "Popular spot for cycling and humor-filled Instagram shots." },
        { name: "Annual Boring & Dull Day", desc: "Celebrate with another 'dull' town — yes, it's a thing." }
    ],
    "truth or consequences": [
        { name: "Hot Springs District", desc: "Healing waters in a city named after a radio show." },
        { name: "Geronimo Springs Museum", desc: "Local history with a quirky vibe." },
        { name: "Elephant Butte Lake", desc: "Nearby, fun name and beautiful outdoor escape." }
    ],
    "intercourse": [
        { name: "Intercourse Village", desc: "Quaint Amish town in Pennsylvania — get the T-shirt!" },
        { name: "The Old Candle Barn", desc: "Traditional handmade goods and curiosities." },
        { name: "Kitchen Kettle Village", desc: "Jam, pickles, and crafts in a hilariously named town." }
    ],
    "hell": [
        { name: "Hell Signpost", desc: "Get your picture taken going to Hell — in Michigan." },
        { name: "Hell Hole Diner", desc: "Hearty meals and hellishly good burgers." },
        { name: "Screams Ice Cream", desc: "Chill in Hell with a cone of chaos." }
    ],
    "no name": [
        { name: "No Name Trail", desc: "Real trail with no name — Colorado humor at its best." },
        { name: "No Name Rest Area", desc: "Yes, it exists — pull over just for the laughs." },
        { name: "Glenwood Canyon Views", desc: "Epic views in a mysteriously nameless place." }
    ],
    "batman": [
        { name: "Batman Sign", desc: "Located in Turkey, selfie spot for superhero fans!" },
        { name: "Tigris River Views", desc: "Relax near this famous river in Batman Province." },
        { name: "Batman Museum", desc: "Regional artifacts — not DC Comics, but still fun!" }
    ],
    "ugly": [
        { name: "Ugly Creek", desc: "Rural Georgia stream with a name to remember." },
        { name: "Selfie with Ugly Sign", desc: "Proof that you visited the 'ugliest' place." },
        { name: "Nature Trails", desc: "Ironically, the area is quite beautiful." }
    ],
    "booger hollow": [
        { name: "Booger Hollow Trading Post", desc: "Oddball roadside attraction in Arkansas." },
        { name: "Double-Decker Outhouse", desc: "Iconic weird roadside photo op." },
        { name: "Quirky Gift Shop", desc: "Grab a ‘Booger Hollow’ souvenir for laughs." }
    ],
    "pee pee township": [
        { name: "Pee Pee Creek", desc: "Yes, it’s real — in Ohio." },
        { name: "Pike Lake State Park", desc: "Lovely park with trails and lake views." },
        { name: "Township Sign", desc: "Most-photographed sign in town — you know why." }
    ],
    "mumbai": [
        { name: "Gateway of India", desc: "Iconic arch monument by the Arabian Sea." },
        { name: "Marine Drive", desc: "Scenic seaside promenade called the Queen’s Necklace." },
        { name: "Elephanta Caves", desc: "Ancient rock-cut temples on Elephanta Island." }
    ],
    "delhi": [
        { name: "India Gate", desc: "War memorial located in the heart of Delhi." },
        { name: "Red Fort", desc: "Historic Mughal fortress and UNESCO World Heritage site." },
        { name: "Qutub Minar", desc: "Tallest brick minaret in the world." }
    ],
    "bengaluru": [
        { name: "Lalbagh Botanical Garden", desc: "Famous garden with a glasshouse inspired by London’s Crystal Palace." },
        { name: "Bangalore Palace", desc: "Majestic palace resembling England’s Windsor Castle." },
        { name: "Cubbon Park", desc: "Large green space and public park in the city center." }
    ],
    "chennai": [
        { name: "Marina Beach", desc: "One of the longest urban beaches in the world." },
        { name: "Fort St. George", desc: "Historic British fort and museum." },
        { name: "Kapaleeshwarar Temple", desc: "Ancient Hindu temple dedicated to Lord Shiva." }
    ],
    "hyderabad": [
        { name: "Charminar", desc: "Famous 16th-century mosque and landmark." },
        { name: "Golconda Fort", desc: "Massive fortress with rich history." },
        { name: "Hussain Sagar Lake", desc: "Artificial lake famous for the Buddha statue." }
    ],
    "ahmedabad": [
        { name: "Sabarmati Ashram", desc: "Mahatma Gandhi’s former residence and museum." },
        { name: "Kankaria Lake", desc: "Popular lake with zoo and amusement park." },
        { name: "Adalaj Stepwell", desc: "Intricately carved historic stepwell." }
    ],
    "jaipur": [
        { name: "Hawa Mahal", desc: "The famous Palace of Winds with unique façade." },
        { name: "Amber Fort", desc: "Massive fort overlooking Maota Lake." },
        { name: "City Palace", desc: "Historic royal palace complex in the city center." }
    ],
    "lucknow": [
        { name: "Bara Imambara", desc: "Grand historical complex with famous labyrinth." },
        { name: "Rumi Darwaza", desc: "Iconic gateway built in Awadhi architectural style." },
        { name: "Hazratganj Market", desc: "Popular shopping and dining area." }
    ],
    "kochi": [
        { name: "Fort Kochi", desc: "Historic neighborhood with colonial architecture." },
        { name: "Chinese Fishing Nets", desc: "Traditional fishing nets unique to Kochi." },
        { name: "Mattancherry Palace", desc: "Dutch Palace with murals and artifacts." }
    ],
    "pune": [
        { name: "Shaniwar Wada", desc: "18th-century fortification and palace." },
        { name: "Aga Khan Palace", desc: "Historical landmark with ties to Gandhi." },
        { name: "Sinhagad Fort", desc: "Popular hill fortress with hiking trails." }
    ],
    "varanasi": [
        { name: "Dashashwamedh Ghat", desc: "Famous riverfront steps on the Ganges." },
        { name: "Kashi Vishwanath Temple", desc: "One of the holiest Hindu temples." },
        { name: "Sarnath", desc: "Important Buddhist pilgrimage site." }
    ],
    "amritsar": [
        { name: "Golden Temple", desc: "Sacred Sikh gurdwara with stunning architecture." },
        { name: "Jallianwala Bagh", desc: "Historic site of the 1919 massacre." },
        { name: "Wagah Border", desc: "Famous border ceremony with Pakistan." }
    ],
    "gurgaon": [
        { name: "Kingdom of Dreams", desc: "Live entertainment and cultural shows." },
        { name: "Cyber Hub", desc: "Popular dining and nightlife area." },
        { name: "Leisure Valley Park", desc: "Large urban park with greenery and lakes." }
    ],
    "indore": [
        { name: "Rajwada Palace", desc: "Historical palace with Maratha architecture." },
        { name: "Lal Bagh Palace", desc: "Royal palace museum." },
        { name: "Sarafa Bazaar", desc: "Famous night street food market." }
    ],
    "surat": [
        { name: "Dumas Beach", desc: "Popular black sand beach." },
        { name: "Sarthana Nature Park", desc: "Zoo and botanical garden." },
        { name: "Surat Castle", desc: "Historic fort built in the 16th century." }
    ],
    "nagpur": [
        { name: "Deekshabhoomi", desc: "Important Buddhist monument." },
        { name: "Futala Lake", desc: "Scenic lake with lighting at night." },
        { name: "Ambazari Lake", desc: "Large lake and garden area." }
    ],
    "mysore": [
        { name: "Mysore Palace", desc: "Grand royal palace known for Dussehra festival." },
        { name: "Chamundi Hill", desc: "Hill with temple and panoramic views." },
        { name: "Brindavan Gardens", desc: "Famous gardens with musical fountain." }
    ],
    "allahabad (prayagraj)": [
        { name: "Triveni Sangam", desc: "Confluence of three rivers, sacred in Hinduism." },
        { name: "Anand Bhavan", desc: "Historic house museum." },
        { name: "Khusro Bagh", desc: "Large Mughal-era garden and tomb complex." }
    ],
    "jodhpur": [
        { name: "Mehrangarh Fort", desc: "Massive fort with museum and views." },
        { name: "Umaid Bhawan Palace", desc: "One of the world’s largest private residences." },
        { name: "Jaswant Thada", desc: "Marble cenotaph near the fort." }
    ],
    "goa": [
        { name: "Baga Beach", desc: "Popular beach with nightlife." },
        { name: "Basilica of Bom Jesus", desc: "UNESCO World Heritage church." },
        { name: "Dudhsagar Falls", desc: "Scenic waterfall on the Goa-Karnataka border." }
    ],
    "bhopal": [
        { name: "Upper Lake", desc: "Historic and scenic freshwater lake." },
        { name: "Taj-ul-Masajid", desc: "One of Asia’s largest mosques." },
        { name: "Sanchi Stupa", desc: "Ancient Buddhist complex and UNESCO site nearby." }
    ],
    "kanpur": [
        { name: "Allen Forest Zoo", desc: "Largest zoological park in Uttar Pradesh." },
        { name: "Jajmau", desc: "Ancient site famous for leather industry." },
        { name: "Moti Jheel", desc: "Popular urban lake and recreational spot." }
    ],
    "nagpur": [
        { name: "Deekshabhoomi", desc: "Important Buddhist monument and pilgrimage site." },
        { name: "Seminary Hill", desc: "Scenic hill area with viewpoints." },
        { name: "Sitabuldi Fort", desc: "Historic fort built during British era." }
    ],
    "thiruvananthapuram": [
        { name: "Padmanabhaswamy Temple", desc: "Famous temple with Dravidian architecture." },
        { name: "Kovalam Beach", desc: "Popular beach destination." },
        { name: "Napier Museum", desc: "Art and natural history museum." }
    ],
    "rajkot": [
        { name: "Watson Museum", desc: "Museum with historical and cultural artifacts." },
        { name: "Kaba Gandhi No Delo", desc: "Mahatma Gandhi’s childhood home." },
        { name: "Rotary Dolls Museum", desc: "Unique museum with doll collections." }
    ],
    "coimbatore": [
        { name: "Marudamalai Temple", desc: "Ancient hill temple dedicated to Lord Murugan." },
        { name: "VOC Park and Zoo", desc: "Popular park and zoological garden." },
        { name: "Siruvani Waterfalls", desc: "Scenic waterfalls and trekking spot." }
    ],
    "varanasi": [
        { name: "Banaras Hindu University", desc: "One of Asia’s largest residential universities." },
        { name: "Manikarnika Ghat", desc: "Famous cremation ghat on the Ganges." },
        { name: "Ramnagar Fort", desc: "Historic fort and museum on the riverbank." }
    ],
    "madurai": [
        { name: "Meenakshi Amman Temple", desc: "Iconic Hindu temple known for its architecture." },
        { name: "Thirumalai Nayakkar Palace", desc: "17th-century palace with Indo-Saracenic style." },
        { name: "Gandhi Memorial Museum", desc: "Museum dedicated to Mahatma Gandhi." }
    ],
    "allahabad (prayagraj)": [
        { name: "Anand Bhavan", desc: "Historical house museum and Gandhi’s ancestral home." },
        { name: "Allahabad Fort", desc: "Mughal fort built by Akbar." },
        { name: "Khushro Bagh", desc: "Large garden housing tombs of Mughal royals." }
    ],
    "tirupati": [
        { name: "Tirumala Venkateswara Temple", desc: "Famous Hindu pilgrimage temple." },
        { name: "Sri Kapileswara Swamy Temple", desc: "Ancient Shiva temple." },
        { name: "Chandragiri Fort", desc: "Historical fort with museum." }
    ],
    "gurugram": [
        { name: "Cyber Hub", desc: "Trendy dining and entertainment district." },
        { name: "Kingdom of Dreams", desc: "Live entertainment and cultural shows." },
        { name: "Leisure Valley Park", desc: "Popular park with musical fountain." }
    ],
    "meerut": [
        { name: "Augarnath Temple", desc: "Ancient Hindu temple with historical importance." },
        { name: "St. John’s Church", desc: "Oldest church built during British era." },
        { name: "Shahid Smarak", desc: "Martyrs’ memorial with historical significance." }
    ],
    "jodhpur": [
        { name: "Mehrangarh Fort", desc: "Massive fort with museums and panoramic views." },
        { name: "Umaid Bhawan Palace", desc: "Lavish palace and luxury hotel." },
        { name: "Jaswant Thada", desc: "White marble cenotaph and garden." }
    ],
    "raipur": [
        { name: "Mahant Ghasidas Museum", desc: "Museum with archaeological and historical artifacts." },
        { name: "Nandan Van Zoo and Safari", desc: "Large zoo and wildlife park." },
        { name: "Doodhadhari Monastery", desc: "Famous religious site with a large statue." }
    ],
    "salem": [
        { name: "Yercaud", desc: "Beautiful hill station with coffee plantations." },
        { name: "Kiliyur Falls", desc: "Scenic waterfall near Yercaud." },
        { name: "Shevaroy Hills", desc: "Hilly region known for trekking and views." }
    ],
    "faridabad": [
        { name: "Surajkund", desc: "Site of the famous Surajkund Mela (craft fair)."},
        { name: "Badkhal Lake", desc: "Natural lake and picnic spot."},
        { name: "Town Park", desc: "Large park with recreational facilities."}
    ],
    "rourkela": [
        { name: "Hanuman Vatika", desc: "Large Hanuman statue and garden." },
        { name: "Vedvyas", desc: "Religious and scenic spot." },
        { name: "Indira Gandhi Park", desc: "Popular park for relaxation." }
    ],
    "mangalore": [
        { name: "St. Aloysius Chapel", desc: "Famous for beautiful fresco paintings." },
        { name: "Panambur Beach", desc: "Popular sandy beach with food stalls." },
        { name: "Kadri Manjunath Temple", desc: "Ancient temple dedicated to Lord Shiva." }
    ],
    "tiruchirappalli": [
        { name: "Rockfort Temple", desc: "Historic temple atop a massive rock." },
        { name: "Jambukeswarar Temple", desc: "One of the Pancha Bhoota Stalas." },
        { name: "Kallanai Dam", desc: "Ancient dam built across the Kaveri river." }
    ],
    "bareilly": [
        { name: "Alakhnath Temple", desc: "Famous Hindu temple with spiritual significance." },
        { name: "Trivati Nath Temple", desc: "Ancient temple dedicated to Lord Shiva." },
        { name: "Fun City", desc: "Popular amusement park." }
    ],
    "sangamner": [
    { "name": "Agasti Rishi Ashram", "desc": "A serene spiritual site near Akole, often visited by pilgrims." },
    { "name": "Sangamner Fort", "desc": "Historic fort located near the town, offering scenic views and local history." },
    { "name": "Pravara Riverbank", "desc": "A peaceful riverside spot ideal for evening walks and local gatherings." }
]

};

// Function to fetch and display weather
function getWeather(city) {
    const apiKey = "9b8a2322ee21f0f7d241249fa8ac6eaa"; // Replace with your actual OpenWeatherMap API key
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                const result = `
        <h2>${data.name}, ${data.sys.country}</h2>
        <p><strong>Temperature:</strong> ${data.main.temp} °C</p>
        <p><strong>Weather:</strong> ${data.weather[0].description}</p>
        <p><strong>Humidity:</strong> ${data.main.humidity}%</p>
        <p><strong>Wind Speed:</strong> ${data.wind.speed} m/s</p>
        <p><strong>Cloudiness:</strong> ${data.clouds.all}%</p>
    `;     
                document.getElementById("weatherResult").innerHTML = result;
            } else {
                document.getElementById("weatherResult").innerHTML = `<p>City not found.</p>`;
            }
        })
        .catch(() => {
            document.getElementById("weatherResult").innerHTML = `<p>Error fetching data.</p>`;
        });
}

// Function to display tourist spots
function getTouristSpots(city) {
    const spots = touristData[city.toLowerCase()];
    const accordion = document.getElementById("accordionExample");
    accordion.innerHTML = ""; // Clear previous

    if (!spots) {
        accordion.innerHTML = `<div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button" type="button" disabled>
                    No tourist data found for "${city}"
                </button>
            </h2>
        </div>`;
        return;
    }

    spots.forEach((spot, index) => {
        accordion.innerHTML += `
        <div class="accordion-item">
            <h2 class="accordion-header" id="heading${index}">
                <button class="accordion-button ${index !== 0 ? 'collapsed' : ''}" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${index}" aria-expanded="${index === 0}" aria-controls="collapse${index}">
                    ${spot.name}
                </button>
            </h2>
            <div id="collapse${index}" class="accordion-collapse collapse ${index === 0 ? 'show' : ''}" aria-labelledby="heading${index}" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    ${spot.desc}
                </div>
            </div>
        </div>`;
    });
}

// Unified function for button
function getWeatherAndTouristSpots() {
    const city = document.getElementById("cityInput").value.trim();
    if (city !== "") {
        getWeather(city);
        getTouristSpots(city);
    }
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("cityInput").addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      getWeatherAndTouristSpots();
    }
  });
});