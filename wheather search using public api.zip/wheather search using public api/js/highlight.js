
  const cities = ["Mumbai", "Delhi", "Kolkata", "Chennai", "Bengaluru", "Hyderabad", "Pune","Nashik","Baramati","Raigarh fort","Navi Mumbai","Pimpri","Mawsynram","Meghalaya","hadpsar","spain","poland","singapur","sangamner","kalyan","dombivali","Mawsynram", "Cherrapunji", "Mumbai", "Kochi", "Bangalore", "Shillong",
"Guwahati", "Kerala (Kochi)", "Mumbai", "Mumbai", "Mumbai", "Mumbai",
"Chennai", "Kolkata", "Darjeeling", "Imphal", "Port Blair", "Agartala",
"Patna", "Gangtok", "Pune", "Coimbatore", "Trivandrum", "Nagpur","sangamner",
"Goa", "Dharamshala", "Shimla", "Kolkata", "Dehradun", "Mysore",
"Medan", "Kuala Lumpur", "Singapore", "Jakarta", "Bangkok", "Manila",
"Hanoi", "Colombo", "Ho Chi Minh City", "Yangon", "Singapore",
"Portland (Oregon, USA)", "Seattle (Washington, USA)", "Vancouver (Canada)",
"London (UK)", "Dublin (Ireland)", "Bergen (Norway)", "Reykjavik (Iceland)",
"Honolulu (Hawaii, USA)", "Fiji", "Darwin (Australia)", "Brisbane (Australia)",
"Cairns (Australia)", "Taipei (Taiwan)", "Hilo (Hawaii, USA)", "Guayaquil (Ecuador)",
"Medellín (Colombia)", "San Juan (Puerto Rico)", "Manaus (Brazil)", "Quito (Ecuador)",
"Monsoon influenced cities like Mumbai, Chennai, Kolkata, Dhaka, and Colombo.","kokan","kullu","theni","tenkasi","kerala","bhutan","egypt","gujrat","ahmadabad","kullu","Baguio, Philippines",
"Lucena, Philippines",
"Naga, Philippines",
"Laoag, Philippines",
"General Santos, Philippines",
"San Fernando, Philippines",
"Kota Kinabalu, Malaysia",
"Sandakan, Malaysia",
"Tawau, Malaysia",
"Sibu, Malaysia",
"Bintulu, Malaysia",
"Miri, Malaysia",
"Bandar Seri Begawan, Brunei",
"Pontianak, Indonesia",
"Samarinda, Indonesia",
"Balikpapan, Indonesia",
"Makassar, Indonesia",
"Kendari, Indonesia",
"Ambon, Indonesia",
"Jayapura, Indonesia",
"Ternate, Indonesia",
"Serang, Indonesia",
"Banjarmasin, Indonesia",
"Pekanbaru, Indonesia",
"Jambi, Indonesia",
"Palu, Indonesia",
"Tarakan, Indonesia",
"Manado, Indonesia",
"Medellín, Colombia",
"Cali, Colombia",
"Pasto, Colombia",
"Ibagué, Colombia",
"Neiva, Colombia",
"Pereira, Colombia",
"Armenia, Colombia",
"Bogotá, Colombia",
"Cartagena, Colombia",
"Santa Marta, Colombia",
"Cúcuta, Colombia",
"Barquisimeto, Venezuela",
"Maracaibo, Venezuela",
"Valencia, Venezuela",
"Caracas, Venezuela",
"Puerto La Cruz, Venezuela",
"Ciudad Bolívar, Venezuela",
"Santo Domingo, Dominican Republic",
"Santiago de los Caballeros, Dominican Republic",
"San Pedro Sula, Honduras",
"Tegucigalpa, Honduras",
"Managua, Nicaragua",
"San Salvador, El Salvador",
"Guatemala City, Guatemala",
"Quetzaltenango, Guatemala",
"Belize City, Belize",
"Orange Walk, Belize",
"Kingston, Jamaica",
"Montego Bay, Jamaica",
"Castries, Saint Lucia",
"Bridgetown, Barbados",
"Port of Spain, Trinidad and Tobago",
"Scarborough, Trinidad and Tobago",
"Paramaribo, Suriname",
"Cayenne, French Guiana",
"Georgetown, Bahamas",
"Nassau, Bahamas",
"Freeport, Bahamas",
"Basse-Terre, Guadeloupe",
"Fort-de-France, Martinique",
"Roseau, Dominica",
"Kingstown, Saint Vincent and the Grenadines",
"Saint George's, Grenada",
"Philipsburg, Sint Maarten",
"Oranjestad, Aruba",
"Willemstad, Curaçao",
"Port-au-Prince, Haiti",
"Cap-Haïtien, Haiti",
"Les Cayes, Haiti",
"Bamenda, Cameroon",
"Garoua, Cameroon",
"Yaoundé, Cameroon",
"Douala, Cameroon",
"Libreville, Gabon",
"Franceville, Gabon",
"Lusaka, Zambia",
"Ndola, Zambia",
"Harare, Zimbabwe",
"Bulawayo, Zimbabwe",
"Blantyre, Malawi",
"Lilongwe, Malawi",
"Maputo, Mozambique",
"Beira, Mozambique",
"Antsiranana, Madagascar",
"Toamasina, Madagascar",
"Majunga, Madagascar",
"Fianarantsoa, Madagascar",
"Morondava, Madagascar",
"Port Louis, Mauritius",
"Curepipe, Mauritius",
"Vacoas, Mauritius",
"Victoria, Seychelles",
  "Mawsynram, India",
  "Cherrapunji, India",
  "Tutunendo, Colombia",
  "Cropp River, New Zealand",
  "Debundscha, Cameroon",
  "Quibdó, Colombia",
  "Lloró, Colombia",
  "Buenaventura, Colombia",
  "Hilo, Hawaii, USA",
  "Mount Waialeale, Hawaii, USA",
  "Big Bog, Hawaii, USA",
  "Mt Bellenden Ker, Australia",
  "Whittier, Alaska, USA",
  "Yakushima, Japan",
  "Milford Sound, New Zealand",
  "Legazpi, Philippines",
  "Manokwari, Indonesia",
  "Iquitos, Peru",
  "Padang, Indonesia",
  "Monrovia, Liberia",
  "Panama City, Panama",
  "Singapore",
  "Macapa, Brazil",
  "Papeete, French Polynesia",
  "Ketchikan, Alaska, USA",
  "Fortaleza, Brazil",
  "Bandarban, Bangladesh",
  "Kuala Lumpur, Malaysia",
  "Manila, Philippines",
  "Ho Chi Minh City, Vietnam",
  "Palembang, Indonesia",
  "Bogor, Indonesia",
  "Kisangani, DRC",
  "Pucallpa, Peru",
  "Medan, Indonesia",
  "Itaituba, Brazil",
  "La Ceiba, Honduras",
  "Georgetown, Guyana",
  "Port Moresby, Papua New Guinea",
  "Cairns, Australia",
  "Darwin, Australia",
  "Phuket, Thailand",
  "Colón, Panama",
  "San José, Costa Rica",
  "Belém, Brazil",
  "Santos, Brazil",
  "Goa, India",
  "Shillong, India",
  "Cochin, India",
  "Kozhikode, India",
  "Thiruvananthapuram, India",
  "Mumbai, India",
  "Pune, India",
  "Mangalore, India",
  "Nagpur, India",
  "Kolkata, India",
  "Guwahati, India",
  "Rangpur, Bangladesh",
  "Sylhet, Bangladesh",
  "Barisal, Bangladesh",
  "Dhaka, Bangladesh",
  "Colombo, Sri Lanka",
  "Galle, Sri Lanka",
  "Nuwara Eliya, Sri Lanka",
  "Paramaribo, Suriname",
  "Libreville, Gabon",
  "Douala, Cameroon",
  "Freetown, Sierra Leone",
  "Accra, Ghana",
  "Cotonou, Benin",
  "Port Harcourt, Nigeria",
  "Uyo, Nigeria",
  "Kigali, Rwanda",
  "Antananarivo, Madagascar",
  "Malabo, Equatorial Guinea",
  "Bangui, Central African Republic",
  "São Tomé, São Tomé and Príncipe",
  "Banjul, Gambia",
  "Conakry, Guinea",
  "Zanzibar City, Tanzania",
  "Moroni, Comoros",
  "Nouméa, New Caledonia",
  "Suva, Fiji",
  "Apia, Samoa",
  "Nukuʻalofa, Tonga",
  "Honiara, Solomon Islands",
  "Avarua, Cook Islands",
  "Pago Pago, American Samoa",
  "Majuro, Marshall Islands",
  "Palikir, Micronesia",
  "Tarawa, Kiribati",
  "Port Vila, Vanuatu",
  "Luganville, Vanuatu",
  "Manila, Philippines",
  "Davao City, Philippines",
  "Cebu City, Philippines",
  "Tacloban, Philippines",
  "Butuan, Philippines",
  "Zamboanga City, Philippines",
"Nouakchott, Mauritania",
"Dakar, Senegal",
"Thies, Senegal",
"Bissau, Guinea-Bissau",
"Lomé, Togo",
"Niamey, Niger",
"Ouagadougou, Burkina Faso",
"Abidjan, Côte d'Ivoire",
"Yamoussoukro, Côte d'Ivoire",
"Bamako, Mali",
"Conakry, Guinea",
"Kampala, Uganda",
"Mbarara, Uganda",
"Jinja, Uganda",
"Nairobi, Kenya",
"Kisumu, Kenya",
"Mombasa, Kenya",
"Arusha, Tanzania",
"Dar es Salaam, Tanzania",
"Dodoma, Tanzania",
"Mwanza, Tanzania",
"Lusaka, Zambia",
"Kitwe, Zambia",
"Blantyre, Malawi",
"Zomba, Malawi",
"Beira, Mozambique",
"Nampula, Mozambique",
"Quelimane, Mozambique",
"Harare, Zimbabwe",
"Mutare, Zimbabwe",
"Windhoek, Namibia",
"Gaborone, Botswana",
"Francistown, Botswana",
"Maseru, Lesotho",
"Mbabane, Eswatini",
"Lobamba, Eswatini",
"Johannesburg, South Africa",
"Durban, South Africa",
"Cape Town, South Africa",
"Port Elizabeth, South Africa",
"East London, South Africa",
"George, South Africa",
"Bloemfontein, South Africa",
"Kimberley, South Africa",
"Polokwane, South Africa",
"Nelspruit, South Africa",
"Manzini, Eswatini",
"Lilongwe, Malawi",
"Bujumbura, Burundi",
"Gitega, Burundi",
"Bujumbura, Burundi",
"Kigali, Rwanda",
"Gisenyi, Rwanda",
"Rubavu, Rwanda",
"Kinshasa, Democratic Republic of the Congo",
"Matadi, DRC",
"Goma, DRC",
"Bukavu, DRC",
"Lubumbashi, DRC",
"Kananga, DRC",
"Likasi, DRC",
"Mbandaka, DRC",
"Brazzaville, Republic of the Congo",
"Pointe-Noire, Republic of the Congo",
"Libreville, Gabon",
"Port-Gentil, Gabon",
"Malabo, Equatorial Guinea",
"Bata, Equatorial Guinea",
"São Tomé, São Tomé and Príncipe",
"Neiafu, Tonga",
"Nukuʻalofa, Tonga",
"Funafuti, Tuvalu",
"Yaren, Nauru",
"Tarawa, Kiribati",
"Bairiki, Kiribati",
"Majuro, Marshall Islands",
"Kwajalein, Marshall Islands",
"Koror, Palau",
"Ngerulmud, Palau",
"Palikir, Micronesia",
"Weno, Micronesia",
"Colonia, Micronesia",
"Pago Pago, American Samoa",
"Alofi, Niue",
"Avarua, Cook Islands",
"Papeete, French Polynesia",
"Faaa, French Polynesia",
"Mahina, French Polynesia",
"Apia, Samoa",
"Leone, American Samoa",
"Vaitape, Bora Bora",
"Suva, Fiji",
"Nadi, Fiji",
"Lautoka, Fiji",
"Labasa, Fiji",
"Port Vila, Vanuatu",
"Luganville, Vanuatu",
"Nouméa, New Caledonia",
"Dumbéa, New Caledonia",
"Mont-Dore, New Caledonia",
"Baie-Mahault, Guadeloupe",
"Sainte-Rose, Guadeloupe",
"Le Lamentin, Martinique",
"Schœlcher, Martinique",
"San Juan, Puerto Rico",
"Ponce, Puerto Rico",
"Mayagüez, Puerto Rico",
"Hato Rey, Puerto Rico",
"Charlotte Amalie, U.S. Virgin Islands",
"Christiansted, U.S. Virgin Islands",
"Road Town, British Virgin Islands",
"Basseterre, Saint Kitts and Nevis",
"Charlestown, Saint Kitts and Nevis",
"Roseau, Dominica",
"Castries, Saint Lucia",
"Soufrière, Saint Lucia",
"Kingstown, Saint Vincent and the Grenadines",
"Chateaubelair, Saint Vincent and the Grenadines",
"Saint George's, Grenada",
"Gouyave, Grenada",
"Bridgetown, Barbados",
"Oistins, Barbados",
"Port of Spain, Trinidad and Tobago",
"San Fernando, Trinidad and Tobago",
"Scarborough, Trinidad and Tobago",
"Paramaribo, Suriname",
"Nieuw Nickerie, Suriname",
"Cayenne, French Guiana",
"Kourou, French Guiana",
"Macapá, Brazil",
"Belém, Brazil",
"Santarém, Brazil",
"Itaituba, Brazil",
"Manaus, Brazil",
"Boa Vista, Brazil",
"Porto Velho, Brazil",
"Rio Branco, Brazil",
"São Luís, Brazil",
"Fortaleza, Brazil",
"Recife, Brazil",
"João Pessoa, Brazil",
"Natal, Brazil",
"Teresina, Brazil",
"Aracaju, Brazil",
"Maceió, Brazil",
"Salvador, Brazil",
"Ilhéus, Brazil",
"Vitória, Brazil",
"Campos dos Goytacazes, Brazil",
"Rio de Janeiro, Brazil",
"Niterói, Brazil",
"São Paulo, Brazil",
"Santos, Brazil",
"Campinas, Brazil",
"Curitiba, Brazil",
"Joinville, Brazil",
"Florianópolis, Brazil",
"Porto Alegre, Brazil",
"Pelotas, Brazil",
"Montevideo, Uruguay",
"Salto, Uruguay",
"Rivera, Uruguay",
"Asunción, Paraguay",
"Ciudad del Este, Paraguay",
"Encarnación, Paraguay",
"La Paz, Bolivia",
"Cochabamba, Bolivia",
"Santa Cruz de la Sierra, Bolivia",
"Sucre, Bolivia",
"Tarija, Bolivia",
"Arequipa, Peru",
"Trujillo, Peru",
"Chiclayo, Peru",
"Piura, Peru",
"Cusco, Peru",
"Huancayo, Peru",
"Iquitos, Peru",
"Callao, Peru",
"Guayaquil, Ecuador",
"Quito, Ecuador",
"Cuenca, Ecuador",
"Machala, Ecuador",
"Esmeraldas, Ecuador",
"Manta, Ecuador",
"Loja, Ecuador",
"Bogotá, Colombia",
"Medellín, Colombia",
"Cali, Colombia",
"Barranquilla, Colombia",
"Cartagena, Colombia",
"Bucaramanga, Colombia",
"Pereira, Colombia",
"Santa Marta, Colombia",
"Cúcuta, Colombia",
"Manizales, Colombia",
"Neiva, Colombia",
"Villavicencio, Colombia",
"Ibagué, Colombia",
"Pasto, Colombia",
"Popayán, Colombia",
"Montería, Colombia",
"Sincelejo, Colombia",
"Valledupar, Colombia",
"Riohacha, Colombia",
"San José del Guaviare, Colombia",
"Leticia, Colombia",
"Panama City, Panama",
"Colón, Panama",
"David, Panama",
"Chitré, Panama",
"Santiago, Panama",
"Tegucigalpa, Honduras",
"San Pedro Sula, Honduras",
"La Ceiba, Honduras",
"Choluteca, Honduras",
"Comayagua, Honduras",
"Santa Rosa de Copán, Honduras",
"Gracias, Honduras",
"Ocotepeque, Honduras",
"San Salvador, El Salvador",
"Santa Ana, El Salvador",
"San Miguel, El Salvador",
"Sonsonate, El Salvador",
"Santa Tecla, El Salvador",
"Apopa, El Salvador",
"Soyapango, El Salvador",
"Guatemala City, Guatemala",
"Quetzaltenango, Guatemala",
"Escuintla, Guatemala",
"Puerto Barrios, Guatemala",
"Antigua Guatemala, Guatemala",
"Mixco, Guatemala",
"Belmopan, Belize",
"Belize City, Belize",
"San Ignacio, Belize",
"Orange Walk Town, Belize",
"Corozal Town, Belize",
"Chetumal, Mexico",
"Villahermosa, Mexico",
"Tuxtla Gutiérrez, Mexico",
"Tapachula, Mexico",
"San Cristóbal de las Casas, Mexico",
"Oaxaca de Juárez, Mexico",
"Veracruz, Mexico",
"Coatzacoalcos, Mexico",
"Minatitlán, Mexico",
"Poza Rica, Mexico",
"Tuxpan, Mexico",
"Puebla, Mexico",
"Xalapa, Mexico",
"Córdoba, Mexico",
"Orizaba, Mexico",
"Tampico, Mexico",
"Ciudad Madero, Mexico",
"Reynosa, Mexico",
"Matamoros, Mexico",
"Monterrey, Mexico",
"Saltillo, Mexico",
"Guadalajara, Mexico",
"Puerto Vallarta, Mexico",
"Tepic, Mexico",
"Colima, Mexico",
"Manzanillo, Mexico",
"Aguascalientes, Mexico",
"Morelia, Mexico",
"Zamora, Mexico",
"Uruapan, Mexico",
"Mexico City, Mexico",
"Toluca, Mexico",
"Cuernavaca, Mexico",
"Pachuca, Mexico",
"Acapulco, Mexico",
"Chilpancingo, Mexico",
"Iguala, Mexico",
"Tuxtla Chico, Mexico",
"Tapilula, Mexico",
"San Andrés Tuxtla, Mexico",
"Campeche, Mexico",
"Ciudad del Carmen, Mexico",
"Mérida, Mexico",
"Progreso, Mexico",
"Chetumal, Mexico",
"Cancún, Mexico",
"Playa del Carmen, Mexico",
"Tulum, Mexico",
"Cozumel, Mexico",
"Havana, Cuba",
"Santiago de Cuba, Cuba",
"Camagüey, Cuba",
"Holguín, Cuba",
"Guantánamo, Cuba",
"Santa Clara, Cuba",
"Bayamo, Cuba",
"Cienfuegos, Cuba",
"Pinar del Río, Cuba",
"Matanzas, Cuba",
"Artemisa, Cuba",
"Las Tunas, Cuba",
"Sancti Spíritus, Cuba",
"Manzanillo, Cuba",
"Morón, Cuba",
"Santa Cruz del Sur, Cuba",
"Guantanamo, Cuba",
"Baracoa, Cuba",
"Moa, Cuba",
"Isabela de Sagua, Cuba",
"Maisí, Cuba",
"Ciego de Ávila, Cuba",
"Colón, Cuba",
"Guáimaro, Cuba",
"Jatibonico, Cuba",
"Yaguajay, Cuba",
"Las Tunas, Cuba",
"Manatí, Cuba",
"Camalú, Mexico",
"Tijuana, Mexico",
"Mexicali, Mexico",
"Ensenada, Mexico",
"Rosarito, Mexico",
"San Quintín, Mexico",
"Guaymas, Mexico",
"Hermosillo, Mexico",
"Ciudad Obregón, Mexico",
"Navojoa, Mexico",
"Los Mochis, Mexico",
"Culiacán, Mexico",
"Mazatlán, Mexico",
"Durango, Mexico",
"Chihuahua, Mexico",
"Ciudad Juárez, Mexico",
"Saltillo, Mexico",
"Monclova, Mexico",
"Nuevo Laredo, Mexico",
"Reynosa, Mexico",
"Matamoros, Mexico",
"Torreón, Mexico",
"Ciudad Victoria, Mexico",
"San Luis Potosí, Mexico",
"Querétaro, Mexico",
"León, Mexico",
"Guanajuato, Mexico",
"Morelia, Mexico",
"Zacatecas, Mexico",
"San Miguel de Allende, Mexico",
"Celaya, Mexico",
"Irapuato, Mexico",
"Silao, Mexico",
"Durango, Mexico",
"Ciudad Valles, Mexico",
"Minatitlán, Mexico",
"Poza Rica, Mexico",
"Coatzacoalcos, Mexico",
"Veracruz, Mexico",
"Tuxpan, Mexico",
"Puebla, Mexico",
"Cholula, Mexico",
"Atlixco, Mexico",
"Tehuacán, Mexico",
"Oaxaca City, Mexico",
"Salina Cruz, Mexico",
"Tuxtla Gutiérrez, Mexico",
"San Cristóbal de las Casas, Mexico",
"Tapachula, Mexico",
"Villahermosa, Mexico",
"Cárdenas, Mexico",
"Campeche, Mexico",
"Ciudad del Carmen, Mexico",
"Mérida, Mexico",
"Progreso, Mexico",
"Cancún, Mexico",
"Playa del Carmen, Mexico",
"Tulum, Mexico",
"Cozumel, Mexico",
"Belize City, Belize",
"San Ignacio, Belize",
"Orange Walk, Belize",
"Corozal, Belize",
"Guatemala City, Guatemala",
"Antigua Guatemala, Guatemala",
"Quetzaltenango, Guatemala",
"Escuintla, Guatemala",
"Puerto Barrios, Guatemala",
"Tegucigalpa, Honduras",
"San Pedro Sula, Honduras",
"La Ceiba, Honduras",
"Comayagua, Honduras",
"Managua, Nicaragua",
"Bluefields, Nicaragua",
"León, Nicaragua",
"Granada, Nicaragua",
"San Salvador, El Salvador",
"Santa Ana, El Salvador",
"San Miguel, El Salvador",
"San José, Costa Rica",
"Limón, Costa Rica",
"Puntarenas, Costa Rica"

];
  const apiKey = "9b8a2322ee21f0f7d241249fa8ac6eaa"; // Replace with your real OpenWeatherMap API key

  async function getRainyCities() {
    let rainyCities = [];

    for (const city of cities) {
      const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

      try {
        const res = await fetch(url);
        const data = await res.json();

        const weatherMain = data.weather[0].main.toLowerCase();
        const hasRain = weatherMain.includes("rain") || data.rain;

        if (hasRain) {
          rainyCities.push({
            name: city,
            temp: data.main.temp,
            description: data.weather[0].description
          });
        }
      } catch (err) {
        console.error(`Error fetching ${city}:`, err);
      }
    }

    // Show top 3 rainy cities
    for (let i = 0; i < 3; i++) {
      const block = document.getElementById(`rainy-city-${i + 1}`);

      if (rainyCities[i]) {
        block.innerHTML = `
          <p><strong>City:</strong> ${rainyCities[i].name}</p>
          <p><strong>Temp:</strong> ${rainyCities[i].temp} °C</p>
          <p><strong>Weather:</strong> ${rainyCities[i].description}</p>
        `;
      } else {
        block.innerHTML = "<p>No rainy city found.</p>";
      }
    }
  }

  getRainyCities();


  //coldest cities
  document.addEventListener("DOMContentLoaded", () => {
    const cities = [
      "Mumbai", "Delhi", "Kolkata", "Chennai", "Bengaluru", "Hyderabad",
      "Pune", "Leh", "Shimla", "Manali", "Barcelona", "Copenhagen"
    ];
    const apiKey = "9b8a2322ee21f0f7d241249fa8ac6eaa";

    async function getColdestCities() {
      let cityTemps = [];

      for (const city of cities) {
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

        try {
          const res = await fetch(url);
          const data = await res.json();

          if (data.main && data.weather) {
            cityTemps.push({
              name: city,
              temp: data.main.temp,
              description: data.weather[0].description
            });
          }

        } catch (err) {
          console.error(`Error fetching ${city}:`, err);
        }
      }

      cityTemps.sort((a, b) => a.temp - b.temp);

      for (let i = 0; i < 3; i++) {
        const block = document.getElementById(`coldest-city-${i + 1}`);

        if (cityTemps[i]) {
          block.innerHTML = `
            <p><strong>City:</strong> ${cityTemps[i].name}</p>
            <p><strong>Temp:</strong> ${cityTemps[i].temp} °C</p>
            <p><strong>Weather:</strong> ${cityTemps[i].description}</p>
          `;
        } else {
          block.innerHTML = "<p>No city data available.</p>";
        }
      }
    }

    getColdestCities();
  });


 //moist cities
  document.addEventListener("DOMContentLoaded", () => {
    const cities = [
      "Mumbai", "Delhi", "Kolkata", "Chennai", "Bengaluru", "Hyderabad",
      "Pune", "Singapore", "Jakarta", "Bangkok", "Kuala Lumpur", "Dubai"
    ];
    const apiKey = "9b8a2322ee21f0f7d241249fa8ac6eaa";

    async function getMostHumidCities() {
      let cityHumidity = [];

      for (const city of cities) {
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

        try {
          const res = await fetch(url);
          const data = await res.json();

          if (data.main && data.weather) {
            cityHumidity.push({
              name: city,
              humidity: data.main.humidity,
              description: data.weather[0].description
            });
          }
        } catch (err) {
          console.error(`Error fetching ${city}:`, err);
        }
      }

      // Sort by highest humidity
      cityHumidity.sort((a, b) => b.humidity - a.humidity);

      // Display top 3 most humid cities
      for (let i = 0; i < 3; i++) {
        const block = document.getElementById(`moist-city-${i + 1}`);
        if (block && cityHumidity[i]) {
          block.innerHTML = `
            <p><strong>City:</strong> ${cityHumidity[i].name}</p>
            <p><strong>Humidity:</strong> ${cityHumidity[i].humidity}%</p>
            <p><strong>Weather:</strong> ${cityHumidity[i].description}</p>
          `;
        } else if (block) {
          block.innerHTML = "<p>No city data available.</p>";
        }
      }
    }

    getMostHumidCities();
  });


  //hottest cities

  document.addEventListener("DOMContentLoaded", () => {
    const cities = [
      "Mumbai", "Delhi", "Kolkata", "Chennai", "Bengaluru", "Hyderabad",
      "Pune", "Dubai", "Bangkok", "Riyadh", "Cairo", "Jakarta"
    ];
    const apiKey = "9b8a2322ee21f0f7d241249fa8ac6eaa";

    async function getHottestCities() {
      let cityTemps = [];

      for (const city of cities) {
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

        try {
          const res = await fetch(url);
          const data = await res.json();

          if (data.main && data.weather) {
            cityTemps.push({
              name: city,
              temp: data.main.temp,
              description: data.weather[0].description
            });
          }

        } catch (err) {
          console.error(`Error fetching ${city}:`, err);
        }
      }

      // Sort by highest temperature (hottest first)
      cityTemps.sort((a, b) => b.temp - a.temp);

      // Display top 3 hottest cities
      for (let i = 0; i < 3; i++) {
        const block = document.getElementById(`hottest-city-${i + 1}`);
        if (block && cityTemps[i]) {
          block.innerHTML = `
            <p><strong>City:</strong> ${cityTemps[i].name}</p>
            <p><strong>Temp:</strong> ${cityTemps[i].temp} °C</p>
            <p><strong>Weather:</strong> ${cityTemps[i].description}</p>
          `;
        } else if (block) {
          block.innerHTML = "<p>No city data available.</p>";
        }
      }
    }

    getHottestCities();
  });
               